import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { fetchDeck, fetchCards, createCard } from "../api";

export default function DeckDetailView({ token }) {
    const { deckId } = useParams();

    const [deck, setDeck] = useState(null);
    const [cards, setCards] = useState([]);
    const [msg, setMsg] = useState("");

    const [question, setQuestion] = useState("");
    const [answer, setAnswer] = useState("");

    async function load() {
        const deckData = await fetchDeck(token, deckId);
        const cardsData = await fetchCards(token, deckId);
        setDeck(deckData);
        setCards(cardsData);
    }

    useEffect(() => {
        if (!token) return;
        load();
    }, [token, deckId]);

    async function onCreate(e) {
        e.preventDefault();

        const q = question.trim();
        const a = answer.trim();
        if (!q || !a) {
            setMsg("Question and answer are required.");
            return;
        }

        setMsg("Creating card...");

        try {
            await createCard(token, deckId, q, a);
            setQuestion("");
            setAnswer("");
            setMsg("✅ Card created");
            await load();
        } catch (e) {
            setMsg("Create card failed: " + (e?.message || String(e)));
        }
    }

    // simple dark styles
    const card = { background: "#1e1e1e", padding: 14, borderRadius: 10, border: "1px solid #2a2a2a" };
    const input = { width: "100%", padding: 12, boxSizing: "border-box", borderRadius: 8, border: "1px solid #333", background: "#111", color: "#fff" };
    const btn = { padding: "10px 12px", cursor: "pointer", background: "#2a2a2a", color: "#fff", border: "1px solid #333", borderRadius: 8 };

    const deckTitle = deck ? (deck.title ?? deck.Title ?? `Deck #${deckId}`) : `Deck #${deckId}`;

    return (
        <div style={{ display: "grid", gap: 12 }}>
            <div style={card}>
                <Link to="/decks" style={{ color: "#fff" }}>← Back to decks</Link>
                <div style={{ marginTop: 10, fontWeight: 800 }}>{deckTitle}</div>
            </div>

            <div style={card}>
                <div style={{ fontWeight: 800, marginBottom: 10 }}>Create card</div>
                <form onSubmit={onCreate} style={{ display: "grid", gap: 10 }}>
                    <input
                        value={question}
                        onChange={(e) => setQuestion(e.target.value)}
                        placeholder="Question"
                        style={input}
                    />
                    <input
                        value={answer}
                        onChange={(e) => setAnswer(e.target.value)}
                        placeholder="Answer"
                        style={input}
                    />
                    <button type="submit" style={btn}>Create</button>
                </form>
            </div>

            <div style={card}>
                <div style={{ fontWeight: 800, marginBottom: 10 }}>Cards</div>

                {cards.length === 0 ? (
                    <div style={{ opacity: 0.7 }}>(No cards yet)</div>
                ) : (
                    <ul style={{ margin: 0, paddingLeft: 18 }}>
                        {cards.map((c, i) => {
                            const id = c.id ?? c.ID ?? i;
                            const q = c.question ?? c.Question ?? "";
                            const a = c.answer ?? c.Answer ?? "";
                            return (
                                <li key={`${id}-${i}`} style={{ marginBottom: 10 }}>
                                    <div><b>Q:</b> {q}</div>
                                    <div style={{ opacity: 0.9 }}><b>A:</b> {a}</div>
                                </li>
                            );
                        })}
                    </ul>
                )}
            </div>

            {msg && <pre style={{ ...card, whiteSpace: "pre-wrap", margin: 0 }}>{msg}</pre>}
        </div>
    );
}
